﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using CommandInterfaceXPS; // Newport Assembly .Net access

namespace XPSApplicationTest
{
    public partial class FormApplicationXPS : Form
    {
        const int EXECUTION_TIMEOUT = 100000;  // Milliseconds
        const int POLLING_TIMEOUT = 20000;     // Milliseconds
        const int POLLING_INTERVALLE_MS = 250; // Milliseconds
        const int NB_POSITIONERS = 2;

        CommandInterfaceXPS.XPS m_xpsInterface = null;           // Socket #1 (order)
        CommandInterfaceXPS.XPS m_xpsInterfaceForPolling = null; // Socket #2 (polling)

        string m_IPAddress;
        int m_IPPort;
        bool m_CommunicationOK;
        string m_GroupName;
        string m_PositionerName;
        bool m_IsPositioner;
        double[] m_TargetPosition = new double[NB_POSITIONERS];
        double[] m_CurrentPosition = new double[NB_POSITIONERS];
        int m_lastGroupState;
        int m_CurrentGroupStatus;
        string m_CurrentGroupStatusDescription;
        string m_XPSControllerVersion;
        string m_errorDescription;

        int m_PollingInterval;
        bool m_pollingFlag;
        private Thread m_PollingThread;

        private Thread m_ExecutionThread;

        public delegate void ChangedCurrentPositionHandler(double[] currentPositions);
        private event ChangedCurrentPositionHandler m_CurrentPositionChanged;
        public event ChangedCurrentPositionHandler PositionChanged
        {
            add { m_CurrentPositionChanged += value; }
            remove { m_CurrentPositionChanged -= value; }
        }
        public delegate void ChangedCurrentGroupStateHandler(int currentGroupStatus, string description);
        private event ChangedCurrentGroupStateHandler m_CurrentGroupStateChanged;
        public event ChangedCurrentGroupStateHandler GroupStatusChanged
        {
            add { m_CurrentGroupStateChanged += value; }
            remove { m_CurrentGroupStateChanged -= value; }
        }
        public delegate void ChangedLabelErrorMessageHandler(string currentErrorMessage);
        private event ChangedLabelErrorMessageHandler m_ErrorMessageChanged;
        public event ChangedLabelErrorMessageHandler ErrorMessageChanged
        {
            add { m_ErrorMessageChanged += value; }
            remove { m_ErrorMessageChanged -= value; }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        public FormApplicationXPS()
        {
            InitializeComponent();

            // Initialization
            label_MessageCommunication.ForeColor = Color.Red;
            label_MessageCommunication.Text = string.Format("Disconnected from XPS");
            m_IsPositioner = false;
            m_CommunicationOK = false;
            m_pollingFlag = false;
            m_PollingInterval = POLLING_INTERVALLE_MS; // milliseconds
            m_CurrentGroupStatus = 0;
            m_lastGroupState = -1;
            for (int i = 0; i < NB_POSITIONERS; i++)
                m_TargetPosition[i] = 0;

            // Events
            if (this != null)
            {
                this.PositionChanged += new ChangedCurrentPositionHandler(CurrentPositionHandlerChanged);
                this.GroupStatusChanged += new ChangedCurrentGroupStateHandler(CurrentGroupStateHandlerChanged);
                this.ErrorMessageChanged += new ChangedLabelErrorMessageHandler(ErrorMessageHandlerChanged);
            }
        }

        private void CurrentPositionHandlerChanged(double[] currentValues)
        {
            string strPosition = currentValues[0].ToString("F6", CultureInfo.CurrentCulture.NumberFormat);

            textBoxPosition.BeginInvoke(
                new Action(() =>
                {
                    textBoxPosition.Text = strPosition;
                }
            ));
        }

        private void CurrentGroupStateHandlerChanged(int currentGroupStatus, string strGroupStatusDescription)
        {
            try
            {
                string strStatus = currentGroupStatus.ToString("F0", CultureInfo.CurrentCulture.NumberFormat);

                textBoxStatus.BeginInvoke(
                   new Action(() =>
                   {
                       textBoxStatus.Text = strStatus;
                   }
                ));

                label_GroupStatusDescription.BeginInvoke(
                   new Action(() =>
                   {
                       label_GroupStatusDescription.Text = strGroupStatusDescription;
                   }
                ));
            }
            catch (Exception ex)
            {
                label_GroupStatusDescription.Text = "Exception in CurrentGroupStateHandlerChanged() : " + ex.Message; // DEBUG
            }
        }

        private void ErrorMessageHandlerChanged(string Message)
        {
            label_ErrorMessage.BeginInvoke(
               new Action(() =>
               {
                   label_ErrorMessage.Text = Message;
               }
            ));
        }

        public void UpdateGroupStatus()
        {
            try
            {
                m_lastGroupState = m_CurrentGroupStatus;
                if (m_xpsInterfaceForPolling != null)
                {
                    string errorString = string.Empty;
                    int result = m_xpsInterfaceForPolling.GroupStatusGet(m_GroupName, out m_CurrentGroupStatus, out errorString);
                    if (result == CommandInterfaceXPS.XPS.FAILURE) // Communication failure with XPS 
                    {
                        m_CurrentGroupStatus = m_lastGroupState;
                        if (errorString.Length > 0)
                        {
                            int errorCode = 0;
                            int.TryParse(errorString, out errorCode);
                            m_xpsInterface.ErrorStringGet(errorCode, out m_errorDescription, out errorString);
                            m_ErrorMessageChanged(string.Format("GroupStatusGet ERROR {0}: {1}", errorCode, m_errorDescription));
                        }
                        else
                            m_ErrorMessageChanged(string.Format("Communication failure with XPS after GroupStatusGet()"));
                    }
                    else
                        result = m_xpsInterfaceForPolling.GroupStatusStringGet(m_CurrentGroupStatus, out m_CurrentGroupStatusDescription, out errorString);

                    if ((m_CurrentGroupStatus != m_lastGroupState) && m_CurrentGroupStateChanged != null)
                        m_CurrentGroupStateChanged(m_CurrentGroupStatus, m_CurrentGroupStatusDescription);
                }
            }
            catch (Exception ex)
            {
                m_ErrorMessageChanged("Exception in UpdateGroupStatus() : " + ex.Message);
            }
        }

        public void UpdateControls()
        {
            if (m_CurrentGroupStatus == m_lastGroupState)
                return;

            switch (m_CurrentGroupStatus)
            {
                case 0:                  // NOTINIT state
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                case 7:
                case 8:
                case 9:
                case 50:
                case 52:
                case 62:
                case 63:
                case 66:
                case 67:
                case 71:
                case 72:
                case 83:
                case 106:
                case 107:
                case 108:
                    buttonInitialize.Enabled = true;
                    buttonHome.Enabled = false;
                    buttonMoveTo.Enabled = false;
                    buttonKill.Enabled = false;
                    break;
                case 42:                  // NOTREF state
                    buttonInitialize.Enabled = false;
                    buttonHome.Enabled = true;
                    buttonMoveTo.Enabled = false;
                    buttonKill.Enabled = true;
                    break;
                case 10:                // READY state
                case 11:
                case 12:
                case 13:
                case 14:
                case 15:
                case 16:
                case 17:
                case 18:
                case 19:
                case 56:
                case 70:
                case 77:
                case 79:
                case 110:
                case 111:
                case 112:
                case 113:
                case 121:
                case 122:
                case 123:
                case 131:
                case 132:
                case 133:
                case 134:
                case 201:
                case 301:
                case 400:
                case 401:
                    buttonInitialize.Enabled = false;
                    buttonHome.Enabled = false;
                    buttonMoveTo.Enabled = true;
                    buttonKill.Enabled = true;
                    break;
                default:            // DISABLE, MOVING and other states
                    buttonInitialize.Enabled = false;
                    buttonHome.Enabled = false;
                    buttonMoveTo.Enabled = false;
                    buttonKill.Enabled = true;
                    break;
            }
        }

        public void UpdateCurrentPosition()
        {
            string PositionerName = TextBox_Group.Text;
            int index = PositionerName.LastIndexOf('.');
            if (index == -1)
            {
                label_ErrorMessage.Text = "Must be a positioner name, not a group name";
                return;
            }

            /*if ((PositionerName != (string)"XY.X") && (PositionerName != (string)"XY.Y")) // Test for XY group only
            {
                label_ErrorMessage.Text = "Positioner name must be XY.X or XY.Y";
                return;
            }
            */

            label_ErrorMessage.Text = string.Empty;
            m_PositionerName = PositionerName;

            try
            {
                double lastCurrentPosition = m_CurrentPosition[0];
                if (m_xpsInterfaceForPolling != null)
                {
                    if (m_IsPositioner == true)
                    {
                        string errorString = string.Empty;
                        int result = m_xpsInterfaceForPolling.GroupPositionCurrentGet(m_PositionerName, out m_CurrentPosition, 1, out errorString);
                        if (result == CommandInterfaceXPS.XPS.FAILURE) // Communication failure with XPS 
                        {
                            m_CurrentPosition[0] = lastCurrentPosition;
                            if (errorString.Length > 0)
                            {
                                int errorCode = 0;
                                int.TryParse(errorString, out errorCode);
                                m_xpsInterface.ErrorStringGet(errorCode, out m_errorDescription, out errorString);
                                m_ErrorMessageChanged(string.Format("GroupPositionCurrentGet ERROR {0}: {1}", errorCode, m_errorDescription));
                            }
                            else
                                m_ErrorMessageChanged(string.Format("Communication failure with XPS after GroupPositionCurrentGet()"));
                        }
                    }

                    if ((m_CurrentPosition[0] != lastCurrentPosition) && m_CurrentPositionChanged != null)
                        m_CurrentPositionChanged(m_CurrentPosition);
                }
            }
            catch (Exception ex)
            {
                m_ErrorMessageChanged("Exception in UpdateCurrentPosition() : " + ex.Message);
            }
        }

        public void StartPolling()
        {
            try
            {
                if (m_pollingFlag == false)
                {
                    UpdateGroupStatus();
                    m_lastGroupState = -1; // Force updating controls
                    UpdateControls();
                    // Start polling
                    m_pollingFlag = true;
                    // Create thread and start it
                    m_PollingThread = new Thread(new ParameterizedThreadStart(poll));
                    m_PollingThread.IsBackground = true;
                    m_PollingThread.Start();
                }
            }
            catch (Exception ex)
            {
                label_ErrorMessage.Text = "Exception in StartPolling() : " + ex.Message;
            }
        }

        public void StopPolling()
        {
            try
            {
                m_pollingFlag = false; // Stop the polling
                if (m_PollingThread != null)
                    m_PollingThread.Abort();
            }
            catch (Exception ex)
            {
                label_ErrorMessage.Text = "Exception in StopPolling() : " + ex.Message;
            }
        }

        public void poll(object obj)
        {
            try
            {
                while ((m_pollingFlag == true) && (m_CommunicationOK == true))
                {
                    UpdateGroupStatus();
                    UpdateCurrentPosition();
                    UpdateControls();
                    // Tempo in relation to the polling frequency
                    Thread.Sleep(m_PollingInterval);
                }
            }
            catch (Exception ex)
            {
                m_ErrorMessageChanged("Exception in poll() : " + ex.Message);
            }
        }

        public void taskInitialize(object obj)
        {
            try
            {
                if (m_CommunicationOK == true)
                {
                    label_ErrorMessage.Text = string.Empty;
                    if (m_xpsInterface != null)
                    {
                        string errorString = string.Empty;
                        int result = m_xpsInterface.GroupInitialize(m_GroupName, out errorString);
                        if (result == CommandInterfaceXPS.XPS.FAILURE) // Communication failure with XPS 
                        {
                            if (errorString.Length > 0)
                            {
                                int errorCode = 0;
                                int.TryParse(errorString, out errorCode);
                                m_xpsInterface.ErrorStringGet(errorCode, out m_errorDescription, out errorString);
                                label_ErrorMessage.Text = string.Format("GroupInitialize ERROR {0}: {1}", errorCode, m_errorDescription);
                            }
                            else
                                label_ErrorMessage.Text = string.Format("Communication failure with XPS after GroupInitialize()");
                        }
                    }
                    else
                        label_ErrorMessage.Text = string.Format("CommandInterfaceXPS is not instantiated");
                }
                else
                    label_ErrorMessage.Text = string.Format("Not connected to XPS");
            }
            catch (Exception ex)
            {
                m_ErrorMessageChanged("Exception in taskInitialize() : " + ex.Message);
            }
        }

        public void taskHomeSearch(object obj)
        {
            try
            {
                if (m_CommunicationOK == true)
                {
                    label_ErrorMessage.Text = string.Empty;
                    if (m_xpsInterface != null)
                    {
                        string errorString = string.Empty;
                        int result = m_xpsInterface.GroupHomeSearch(m_GroupName, out errorString);
                        if (result == CommandInterfaceXPS.XPS.FAILURE) // Communication failure with XPS 
                        {
                            if (errorString.Length > 0)
                            {
                                int errorCode = 0;
                                int.TryParse(errorString, out errorCode);
                                m_xpsInterface.ErrorStringGet(errorCode, out m_errorDescription, out errorString);
                                label_ErrorMessage.Text = string.Format("GroupHomeSearch ERROR {0}: {1}", errorCode, m_errorDescription);
                            }
                            else
                                label_ErrorMessage.Text = string.Format("Communication failure with XPS after GroupHomeSearch()");
                        }
                    }
                    else
                        label_ErrorMessage.Text = string.Format("CommandInterfaceXPS is not instantiated");
                }
                else
                    label_ErrorMessage.Text = string.Format("Not connected to XPS");
            }
            catch (Exception ex)
            {
                m_ErrorMessageChanged("Exception in taskHomeSearch() : " + ex.Message);
            }
        }

        public void taskKill(object obj)
        {
            try
            {
                if (m_CommunicationOK == true)
                {
                    label_ErrorMessage.Text = string.Empty;
                    if (m_xpsInterface != null)
                    {
                        string errorString = string.Empty;
                        int result = m_xpsInterface.GroupKill(m_GroupName, out errorString);
                        if (result == CommandInterfaceXPS.XPS.FAILURE) // Communication failure with XPS 
                        {
                            if (errorString.Length > 0)
                            {
                                int errorCode = 0;
                                int.TryParse(errorString, out errorCode);
                                m_xpsInterface.ErrorStringGet(errorCode, out m_errorDescription, out errorString);
                                label_ErrorMessage.Text = string.Format("GroupKill ERROR {0}: {1}", errorCode, m_errorDescription);
                            }
                            else
                                label_ErrorMessage.Text = string.Format("Communication failure with XPS after GroupKill()");
                        }
                    }
                    else
                        label_ErrorMessage.Text = string.Format("CommandInterfaceXPS is not instantiated");
                }
                else
                    label_ErrorMessage.Text = string.Format("Not connected to XPS");
            }
            catch (Exception ex)
            {
                m_ErrorMessageChanged("Exception in taskKill() : " + ex.Message);
            }
        }

        public void taskMoveAbsolute(object obj)
        {
            try
            {
                if (m_CommunicationOK == true)
                {
                    label_ErrorMessage.Text = string.Empty;
                    double.TryParse(textBoxTarget.Text, out m_TargetPosition[0]);
                    if (m_xpsInterface != null)
                    {
                        string errorString = string.Empty;
                        int result = m_xpsInterface.GroupMoveAbsolute(m_PositionerName, m_TargetPosition, 1, out errorString);
                        if (result == CommandInterfaceXPS.XPS.FAILURE) // Communication failure with XPS 
                        {
                            if (errorString.Length > 0)
                            {
                                int errorCode = 0;
                                int.TryParse(errorString, out errorCode);
                                m_xpsInterface.ErrorStringGet(errorCode, out m_errorDescription, out errorString);
                                label_ErrorMessage.Text = string.Format("GroupMoveAbsolute ERROR {0}: {1}", errorCode, m_errorDescription);
                            }
                            else
                                label_ErrorMessage.Text = string.Format("Communication failure with XPS after GroupMoveAbsolute()");
                        }
                    }
                    else
                        label_ErrorMessage.Text = string.Format("CommandInterfaceXPS is not instantiated");
                }
                else
                    label_ErrorMessage.Text = string.Format("Not connected to XPS");
            }
            catch (Exception ex)
            {
                m_ErrorMessageChanged("Exception in taskMoveAbsolute() : " + ex.Message);
            }
        }

        /// <summary>
        /// Socket opening and start polling
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ConnectButton(object sender, EventArgs e)
        {
            // Get IP address and Ip port from form front panel
            m_IPAddress = textBox_IPAddress.Text;
            int.TryParse(textBox_IPPort.Text, out m_IPPort);

            m_PositionerName = TextBox_Group.Text;
            int index = m_PositionerName.LastIndexOf('.');
            if (index != -1)
            {
                m_IsPositioner = true;
                m_GroupName = m_PositionerName.Substring(0, index);
                label_ErrorMessage.Text = string.Empty;
            }
            else
            {
                m_IsPositioner = false;
                m_GroupName = m_PositionerName;
                label_ErrorMessage.Text = "Must be a positioner name, not a group name";
            }

            label_GroupStatusDescription.Text = string.Empty;
            m_XPSControllerVersion = string.Empty;
            m_errorDescription = string.Empty;

            try
            {
                // Open socket #1 to order
                if (m_xpsInterface == null)
                    m_xpsInterface = new CommandInterfaceXPS.XPS();
                if (m_xpsInterface != null)
                {
                    // Open socket
                    int returnValue = m_xpsInterface.OpenInstrument(m_IPAddress, m_IPPort, EXECUTION_TIMEOUT);
                    if (returnValue == 0)
                    {
                        string errorString = string.Empty;
                        string strResponse = string.Empty;
                        int result = m_xpsInterface.FirmwareVersionGet(out m_XPSControllerVersion, out errorString);
                        if (result == CommandInterfaceXPS.XPS.FAILURE) // Communication failure with XPS 
                        {
                            if (errorString.Length > 0)
                            {
                                int errorCode = 0;
                                int.TryParse(errorString, out errorCode);
                                m_xpsInterface.ErrorStringGet(errorCode, out m_errorDescription, out errorString);
                                m_XPSControllerVersion = string.Format("FirmwareVersionGet ERROR {0}: {1}", errorCode, m_errorDescription);
                            }
                            else
                                m_XPSControllerVersion = string.Format("Communication failure with XPS after FirmwareVersionGet ");
                        }
                        else
                        {
                            label_MessageCommunication.ForeColor = Color.Green;
                            label_MessageCommunication.Text = string.Format("Connected to XPS ");
                            m_CommunicationOK = true;
                        }
                    }
                }
                else
                    m_XPSControllerVersion = "XPS instance is NULL";

                // Open socket #2 for polling
                if (m_xpsInterfaceForPolling == null)
                    m_xpsInterfaceForPolling = new CommandInterfaceXPS.XPS();
                if (m_xpsInterfaceForPolling != null)
                {
                    // Open socket
                    int returnValue = m_xpsInterfaceForPolling.OpenInstrument(m_IPAddress, m_IPPort, POLLING_TIMEOUT);
                    if (returnValue == 0)
                    {
                        string errorString = string.Empty;
                        int result = m_xpsInterfaceForPolling.FirmwareVersionGet(out m_XPSControllerVersion, out errorString);
                        if (result != CommandInterfaceXPS.XPS.FAILURE) // Communication failure with XPS 
                        {
                            buttonConnect.Enabled = false;
                            buttonDisconnect.Enabled = true;
                            buttonInitialize.Enabled = true;
                            buttonHome.Enabled = false;
                            buttonMoveTo.Enabled = false;
                            buttonKill.Enabled = false;
                            // Polling status and position
                            StartPolling();
                        }
                    }
                }

                if (m_XPSControllerVersion.Length <= 0)
                    m_XPSControllerVersion = "No detected XPS";

                this.Text = string.Format("XPS Application Test V1.0.0 - {0}", m_XPSControllerVersion);
            }
            catch (Exception ex)
            {
                label_ErrorMessage.Text = "Exception in ConnectButton: " + ex.Message;
            }
        }

        /// <summary>
        /// Stop polling and Close socket
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonDisconnect_Click(object sender, EventArgs e)
        {
            try
            {
                m_pollingFlag = false;
                m_CommunicationOK = false;

                if (m_xpsInterfaceForPolling != null)
                    m_xpsInterfaceForPolling.CloseInstrument();

                if (m_xpsInterface != null)
                    m_xpsInterface.CloseInstrument();

                // Enable or disable the controls
                buttonConnect.Enabled = true;
                buttonDisconnect.Enabled = false;
                buttonInitialize.Enabled = false;
                buttonHome.Enabled = false;
                buttonMoveTo.Enabled = false;
                buttonKill.Enabled = false;
                label_MessageCommunication.ForeColor = Color.Red;
                label_MessageCommunication.Text = string.Format("Disconnected from XPS");
                label_ErrorMessage.Text = string.Empty;
                label_GroupStatusDescription.Text = string.Empty;
                m_XPSControllerVersion = string.Empty;
                m_errorDescription = string.Empty;
                this.Text = "XPS Application";
            }
            catch (Exception ex)
            {
                label_ErrorMessage.Text = "Exception in buttonDisconnect_Click: " + ex.Message;
            }
        }

        /// <summary>
        /// Button to perform a GroupInitialize
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonInitialize_Click(object sender, EventArgs e)
        {
            try
            {
                // Create task and launch
                m_ExecutionThread = new Thread(new ParameterizedThreadStart(taskInitialize));
                m_ExecutionThread.IsBackground = true;
                m_ExecutionThread.Start();
            }
            catch (Exception ex)
            {
                label_ErrorMessage.Text = "Exception in buttonInitialize_Click: " + ex.Message;
            }
        }

        /// <summary>
        /// Button to perform a group home search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonHome_Click(object sender, EventArgs e)
        {
            try
            {
                // Create task and launch
                m_ExecutionThread = new Thread(new ParameterizedThreadStart(taskHomeSearch));
                m_ExecutionThread.IsBackground = true;
                m_ExecutionThread.Start();
            }
            catch (Exception ex)
            {
                label_ErrorMessage.Text = "Exception in buttonHome_Click: " + ex.Message;
            }
        }

        /// <summary>
        /// Button to perform a group kill
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonKill_Click(object sender, EventArgs e)
        {
            try
            {
                // Create task and launch
                m_ExecutionThread = new Thread(new ParameterizedThreadStart(taskKill));
                m_ExecutionThread.IsBackground = true;
                m_ExecutionThread.Start();
            }
            catch (Exception ex)
            {
                label_ErrorMessage.Text = "Exception in buttonKill_Click() : " + ex.Message;
            }
        }
        /// <summary>
        /// Button to perform an absolute motion
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonMoveTo_Click(object sender, EventArgs e)
        {
            try
            {
                // Create task and launch
                m_ExecutionThread = new Thread(new ParameterizedThreadStart(taskMoveAbsolute));
                m_ExecutionThread.IsBackground = true;
                m_ExecutionThread.Start();
            }
            catch (Exception ex)
            {
                label_ErrorMessage.Text = "Exception in buttonMoveTo_Click() : " + ex.Message;
            }
        }
    }
}
